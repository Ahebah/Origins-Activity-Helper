#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/origins-activity-helper"
UNIT_DIR="$HOME/.config/systemd/user"
UNIT="$UNIT_DIR/origins-activity-helper.service"

mkdir -p "$DEST" "$UNIT_DIR"
cp "$HERE/origins_activity_helper.py" "$DEST/origins_activity_helper.py"
chmod +x "$DEST/origins_activity_helper.py"

python3 "$DEST/origins_activity_helper.py" --configure

cat > "$UNIT" <<EOF
[Unit]
Description=Origins The Isle Activity Helper
After=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 $DEST/origins_activity_helper.py
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now origins-activity-helper.service

echo
systemctl --user --no-pager --full status origins-activity-helper.service | sed -n '1,18p'
echo
echo "Installed. No terminal needs to stay open."
