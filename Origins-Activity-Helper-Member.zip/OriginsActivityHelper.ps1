param(
    [string]$Endpoint = "",
    [string]$PairToken = "",
    [switch]$Install
)

$ErrorActionPreference = "Stop"
$Base = Join-Path $env:LOCALAPPDATA "OriginsActivityHelper"
$ConfigPath = Join-Path $Base "config.json"
$LogPath = Join-Path $env:LOCALAPPDATA "TheIsle\Saved\Logs\TheIsle.log"
$CachePath = Join-Path $Base "servers-cache.json"

function Configure-OriginsHelper {
    if (-not $Endpoint) { $script:Endpoint = Read-Host "Server URL" }
    if (-not $PairToken) { $script:PairToken = Read-Host "Pairing token" }

    if ($PairToken -notmatch '^([0-9a-f]{16})\.(.{20,})$') {
        throw "Invalid pairing token."
    }

    New-Item -ItemType Directory -Force -Path $Base | Out-Null
    @{
        endpoint = $Endpoint.TrimEnd("/")
        key_id = $Matches[1]
        secret = $Matches[2]
        poll_seconds = 30
    } | ConvertTo-Json | Set-Content -Encoding UTF8 $ConfigPath
}

function Get-GameRunning {
    return [bool](Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -like "TheIsleClient-Win64-Shipping*" -or
        $_.ProcessName -eq "TheIsle"
    } | Select-Object -First 1)
}

function Get-DetectedEndpoint {
    if (-not (Test-Path $LogPath)) {
        return @{ endpoint = $null; menu = $true }
    }

    $lines = Get-Content -Path $LogPath -Tail 8000 -ErrorAction SilentlyContinue
    $latestBrowse = -1
    $latestDisconnect = -1
    $endpoint = $null
    $browseWithoutEndpoint = $false

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = [string]$lines[$i]

        if ($line -match 'UEngine::Browse Started Browse:\s*"([^"]*)"') {
            $latestBrowse = $i
            $target = $Matches[1]
            if ($target -match '^((?:\d{1,3}\.){3}\d{1,3})(?::(\d{1,5}))?/') {
                $endpoint = if ($Matches[2]) { "$($Matches[1]):$($Matches[2])" } else { $Matches[1] }
                $browseWithoutEndpoint = $false
            } else {
                $endpoint = $null
                $browseWithoutEndpoint = $true
            }
        }

        if ($line -match '(NetworkFailure|ConnectionLost|Connection\s+TIMED\s+OUT|UNetConnection::Close|TravelFailure)') {
            $latestDisconnect = $i
        }
    }

    $menu = (($latestDisconnect -gt $latestBrowse) -and ($latestBrowse -ge 0)) -or
            (($latestBrowse -ge 0) -and $browseWithoutEndpoint)

    return @{ endpoint = $endpoint; menu = $menu }
}

function Get-ServerMap($Cfg) {
    try {
        $response = Invoke-RestMethod -Uri "$($Cfg.endpoint)/v1/servers" -Method Get -TimeoutSec 12
        $map = @{}
        foreach ($row in $response.servers) {
            $map[[string]$row.name] = @($row.endpoints | ForEach-Object { [string]$_ })
        }
        $map | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $CachePath
        return $map
    } catch {
        if (Test-Path $CachePath) {
            return Get-Content $CachePath -Raw | ConvertFrom-Json -AsHashtable
        }
        return @{}
    }
}

function Resolve-State($Map) {
    if (-not (Get-GameRunning)) {
        return @{ state = "offline"; server = "" }
    }

    $det = Get-DetectedEndpoint
    if (-not $det.endpoint -or $det.menu) {
        return @{ state = "main_menu"; server = "The Isle — Main Menu" }
    }

    foreach ($name in $Map.Keys) {
        if (@($Map[$name]) -contains [string]$det.endpoint) {
            if ($name -eq "Origins") {
                return @{ state = "origins"; server = "Origins" }
            }
            if ($name -match '^Official EU \d{1,2}$') {
                return @{ state = "official_eu"; server = $name }
            }
        }
    }

    return @{ state = "other"; server = "The Isle — Other Server" }
}

function Send-Status($Cfg, $State, $Server) {
    $timestamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $nonce = ([Convert]::ToBase64String([Security.Cryptography.RandomNumberGenerator]::GetBytes(12))).TrimEnd('=').Replace('+','_').Replace('/','_')
    $canonical = "v1|$($Cfg.key_id)|$timestamp|$nonce|$State|$Server"

    $key = [Text.Encoding]::UTF8.GetBytes([string]$Cfg.secret)
    $h = [Security.Cryptography.HMACSHA256]::new($key)
    try {
        $hash = $h.ComputeHash([Text.Encoding]::UTF8.GetBytes($canonical))
    } finally {
        $h.Dispose()
    }
    $signature = ($hash | ForEach-Object { $_.ToString("x2") }) -join ""

    $body = @{
        key_id = [string]$Cfg.key_id
        timestamp = $timestamp
        nonce = $nonce
        state = $State
        server = $Server
        signature = $signature
    } | ConvertTo-Json -Compress

    Invoke-RestMethod -Uri "$($Cfg.endpoint)/v1/activity" -Method Post `
        -ContentType "application/json" -Body $body -TimeoutSec 12 | Out-Null
}

if ($Install) {
    Configure-OriginsHelper
    $Startup = [Environment]::GetFolderPath("Startup")
    $Cmd = Join-Path $Startup "Origins Activity Helper.cmd"
    $Self = $MyInvocation.MyCommand.Path
    "@echo off`r`nstart `"`" /min powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Self`"`r`n" |
        Set-Content -Encoding ASCII $Cmd
    Write-Host "Installed. The helper will start automatically at Windows sign-in."
    Start-Process powershell.exe -WindowStyle Hidden -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$Self`""
    exit
}

if (-not (Test-Path $ConfigPath)) {
    Configure-OriginsHelper
}

$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json
$map = @{}
$mapAt = [DateTime]::MinValue
$lastState = ""
$lastServer = ""
$lastSent = [DateTime]::MinValue

while ($true) {
    if ((Get-Date) -gt $mapAt.AddMinutes(5) -or $map.Count -eq 0) {
        $map = Get-ServerMap $cfg
        $mapAt = Get-Date
    }

    $result = Resolve-State $map
    if ($result.state -ne $lastState -or $result.server -ne $lastServer -or
        (Get-Date) -gt $lastSent.AddSeconds(60)) {
        try {
            Send-Status $cfg $result.state $result.server
            $lastState = $result.state
            $lastServer = $result.server
            $lastSent = Get-Date
        } catch {
            # Keep retrying quietly; activity sharing is non-critical.
        }
    }

    Start-Sleep -Seconds 30
}
