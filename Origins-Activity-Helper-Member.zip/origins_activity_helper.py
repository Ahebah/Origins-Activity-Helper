#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import platform
import re
import secrets
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

APP_ID = "376210"
BROWSE_RE = re.compile(r'UEngine::Browse Started Browse:\s*"([^"]*)"', re.IGNORECASE)
IP_PORT_RE = re.compile(r"^((?:\d{1,3}\.){3}\d{1,3})(?::(\d{1,5}))?/")
DISCONNECT_RE = re.compile(
    r"(NetworkFailure|ConnectionLost|Connection\s+TIMED\s+OUT|"
    r"UNetConnection::Close|TravelFailure)",
    re.IGNORECASE,
)

if os.name == "nt":
    CONFIG_DIR = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "OriginsActivityHelper"
else:
    CONFIG_DIR = Path(
        os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
    ) / "origins-activity-helper"

CONFIG_PATH = CONFIG_DIR / "config.json"
CACHE_PATH = CONFIG_DIR / "servers-cache.json"


def load_config() -> dict:
    if not CONFIG_PATH.exists():
        raise RuntimeError(
            f"No config found at {CONFIG_PATH}. Run this helper with --configure first."
        )
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def save_config(endpoint: str, pair_token: str) -> None:
    key_id, sep, secret = pair_token.strip().partition(".")
    if not sep or not re.fullmatch(r"[0-9a-f]{16}", key_id) or len(secret) < 20:
        raise ValueError("That pairing token is not valid.")

    endpoint = endpoint.strip().rstrip("/")
    if not endpoint.startswith(("http://", "https://")):
        raise ValueError("Server URL must start with http:// or https://")

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(
            {
                "endpoint": endpoint,
                "key_id": key_id,
                "secret": secret,
                "poll_seconds": 30,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except OSError:
        pass


def configure() -> None:
    print("Origins Activity Helper — one-time setup")
    endpoint = input("Server URL: ").strip()
    pair_token = input("Pairing token: ").strip()
    save_config(endpoint, pair_token)
    print(f"\nSaved private config to {CONFIG_PATH}")


def steam_roots_linux() -> list[Path]:
    home = Path.home()
    roots = []
    for path in (
        home / ".local/share/Steam",
        home / ".steam/steam",
        home / ".steam/root",
    ):
        if path.exists():
            roots.append(path)

    for base in list(roots):
        vdf = base / "steamapps/libraryfolders.vdf"
        try:
            text = vdf.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for match in re.finditer(r'"path"\s+"([^"]+)"', text):
            path = Path(match.group(1).replace("\\\\", "\\"))
            if path.exists():
                roots.append(path)

    seen = set()
    result = []
    for path in roots:
        if str(path) not in seen:
            seen.add(str(path))
            result.append(path)
    return result


def candidate_logs() -> list[Path]:
    if os.name == "nt":
        local = Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
        return [local / "TheIsle/Saved/Logs/TheIsle.log"]

    result = []
    for root in steam_roots_linux():
        path = (
            root
            / "steamapps/compatdata"
            / APP_ID
            / "pfx/drive_c/users/steamuser/AppData/Local/TheIsle/Saved/Logs/TheIsle.log"
        )
        if path.exists() and path not in result:
            result.append(path)
    return result


def game_running() -> bool:
    if os.name == "nt":
        try:
            output = subprocess.check_output(
                ["tasklist", "/FO", "CSV", "/NH"],
                text=True,
                stderr=subprocess.DEVNULL,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            ).lower()
        except Exception:
            return False
        return (
            "theisleclient-win64-shipping.exe" in output
            or '"theisle.exe"' in output
        )

    proc = Path("/proc")
    if not proc.exists():
        return False
    for item in proc.iterdir():
        if not item.name.isdigit():
            continue
        try:
            cmd = (
                (item / "cmdline")
                .read_bytes()
                .replace(b"\0", b" ")
                .decode("utf-8", errors="ignore")
                .lower()
            )
        except OSError:
            continue
        if (
            "theisleclient-win64-shipping.exe" in cmd
            or ("theisle.exe" in cmd and "theisleserver" not in cmd)
        ):
            return True
    return False


def latest_log_lines() -> list[str]:
    best = None
    best_mtime = -1.0
    for path in candidate_logs():
        try:
            mtime = path.stat().st_mtime
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            continue
        if mtime > best_mtime:
            best_mtime = mtime
            best = lines
    return best or []


def detect_endpoint() -> tuple[str | None, bool]:
    """Return endpoint and whether a later disconnect/menu event exists."""
    lines = latest_log_lines()
    latest_browse = -1
    latest_disconnect = -1
    endpoint = None
    browse_without_endpoint = False

    for index, line in enumerate(lines):
        browse = BROWSE_RE.search(line)
        if browse:
            latest_browse = index
            target = browse.group(1)
            match = IP_PORT_RE.match(target)
            if match:
                host = match.group(1)
                port = match.group(2)
                endpoint = f"{host}:{port}" if port else host
                browse_without_endpoint = False
            else:
                endpoint = None
                browse_without_endpoint = True

        if DISCONNECT_RE.search(line):
            latest_disconnect = index

    menu_after = latest_disconnect > latest_browse >= 0
    if browse_without_endpoint and latest_browse >= 0:
        menu_after = True
    return endpoint, menu_after


def http_json(url: str, *, body: dict | None = None, timeout: int = 12) -> dict:
    data = None
    headers = {"User-Agent": "OriginsActivityHelper/1.0"}
    method = "GET"
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
        method = "POST"

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def fetch_server_map(endpoint: str) -> dict[str, list[str]]:
    try:
        payload = http_json(endpoint.rstrip("/") + "/v1/servers")
        mapping = {
            str(row["name"]): [str(x) for x in row.get("endpoints") or []]
            for row in payload.get("servers") or []
        }
        if mapping:
            CACHE_PATH.write_text(json.dumps(mapping, indent=2), encoding="utf-8")
            return mapping
    except Exception as exc:
        print(f"[helper] Server-map refresh failed: {exc}", file=sys.stderr)

    if CACHE_PATH.exists():
        try:
            return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def resolve_state(server_map: dict[str, list[str]]) -> tuple[str, str]:
    if not game_running():
        return "offline", ""

    endpoint, menu_after = detect_endpoint()
    if not endpoint or menu_after:
        return "main_menu", "The Isle — Main Menu"

    for name, endpoints in server_map.items():
        if endpoint in endpoints:
            if name == "Origins":
                return "origins", "Origins"
            if re.fullmatch(r"Official EU \d{1,2}", name):
                return "official_eu", name

    return "other", "The Isle — Other Server"


def sign_update(config: dict, state: str, server: str) -> dict:
    timestamp = int(time.time())
    nonce = secrets.token_urlsafe(12).replace("-", "_")
    key_id = str(config["key_id"])
    canonical = f"v1|{key_id}|{timestamp}|{nonce}|{state}|{server}".encode("utf-8")
    signature = hmac.new(
        str(config["secret"]).encode("utf-8"),
        canonical,
        hashlib.sha256,
    ).hexdigest()
    return {
        "key_id": key_id,
        "timestamp": timestamp,
        "nonce": nonce,
        "state": state,
        "server": server,
        "signature": signature,
    }


def send_status(config: dict, state: str, server: str) -> None:
    payload = sign_update(config, state, server)
    result = http_json(
        str(config["endpoint"]).rstrip("/") + "/v1/activity",
        body=payload,
    )
    if not result.get("ok"):
        raise RuntimeError(f"Origins returned: {result}")


def run_once(config: dict, server_map: dict | None = None) -> tuple[str, str, dict]:
    mapping = server_map or fetch_server_map(str(config["endpoint"]))
    state, server = resolve_state(mapping)
    send_status(config, state, server)
    return state, server, mapping


def run_loop() -> None:
    config = load_config()
    poll = max(15, int(config.get("poll_seconds") or 30))
    mapping: dict[str, list[str]] = {}
    map_refreshed = 0.0
    last_state: tuple[str, str] | None = None
    last_sent = 0.0

    print("Origins Activity Helper running.")
    print("Only resolved activity labels are sent; raw server endpoints remain on this PC.")

    while True:
        now = time.monotonic()
        if not mapping or now - map_refreshed >= 300:
            mapping = fetch_server_map(str(config["endpoint"]))
            map_refreshed = now

        state, server = resolve_state(mapping)
        current = (state, server)

        # Send immediately on change; otherwise heartbeat once per minute.
        if current != last_state or now - last_sent >= 60:
            try:
                send_status(config, state, server)
                print(f"[helper] {state}: {server or '-'}")
                last_state = current
                last_sent = now
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                print(f"[helper] HTTP {exc.code}: {body}", file=sys.stderr)
            except Exception as exc:
                print(f"[helper] update failed: {exc}", file=sys.stderr)

        time.sleep(poll)


def main() -> None:
    parser = argparse.ArgumentParser(description="Origins automatic The Isle activity helper")
    parser.add_argument("--configure", action="store_true")
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    if args.configure:
        configure()
        return

    config = load_config()
    if args.once:
        state, server, _ = run_once(config)
        print(f"{state}: {server or '-'}")
        return

    run_loop()


if __name__ == "__main__":
    main()
