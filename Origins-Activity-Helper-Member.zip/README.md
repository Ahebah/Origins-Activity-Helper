# Origins Activity Helper

Optional helper for members who want exact **Origins / Official EU** activity on Discord.

The helper:
- watches only The Isle's local `TheIsle.log`;
- downloads the public Origins/Official-EU endpoint map from the self-hosted Origins Bot;
- resolves the raw server endpoint locally;
- sends only a signed label: `Origins`, `Official EU N`, `Main Menu`, `Other Server`, or `Offline`;
- never sends Steam passwords, Steam Guard, Discord tokens, or raw server endpoints;
- never needs a terminal left open after installation.

## Pair first

In Discord use:

`/activity-helper-setup`

Copy the **Server URL** and **Pairing token** shown in the private response.

## Linux / Steam Proton

```bash
chmod +x install-linux.sh origins_activity_helper.py
./install-linux.sh
```

Paste the Server URL and Pairing token when asked.

The helper is installed as a user systemd service.

## Windows

Right-click PowerShell and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install-Windows.ps1
```

Paste the Server URL and Pairing token when asked.

It adds a current-user Startup entry; no administrator rights are required.

## Revoke

Use `/activity-helper-remove` in Discord. A newly generated pairing token automatically
replaces/revokes the previous one.
