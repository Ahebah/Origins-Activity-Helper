param(
    [string]$Endpoint = "",
    [string]$PairToken = ""
)

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = Join-Path $env:LOCALAPPDATA "OriginsActivityHelper"
New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Copy-Item (Join-Path $Here "OriginsActivityHelper.ps1") (Join-Path $Dest "OriginsActivityHelper.ps1") -Force

& powershell.exe -NoProfile -ExecutionPolicy Bypass `
    -File (Join-Path $Dest "OriginsActivityHelper.ps1") `
    -Endpoint $Endpoint -PairToken $PairToken -Install
